# Databases_and_SQL_for_Data_Science-Coursera

## Description 
This course teaches a lot of things, since how to run basic queries until modeling databases. 
What was nice about the learnings, is about the exercises using real data!

## Topics
-> Statements: CREATE, DELETE, SELECT, INSERT and UPDATE table.

-> COUNT, LIMIT, DISTINCT.

-> String Patterns, Ranges, Sorting, Grouping.

-> Sub-queries and multiple tables(implicit join)

-> Database access from Python.

-> Analyzing data with Python.

-> JOIN(inner, outer).

-> Working with real-word datasets.

-> Relational databases concepts.

-> Relational Model Constraints.
 
